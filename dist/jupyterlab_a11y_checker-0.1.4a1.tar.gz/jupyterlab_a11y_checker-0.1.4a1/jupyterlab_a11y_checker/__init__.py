def _jupyter_labextension_paths():
    return [{
        "src": "labextension",
        "dest": "jupyterlab-a11y-checker"
    }]