import { JupyterFrontEndPlugin } from '@jupyterlab/application';
declare const plugin: JupyterFrontEndPlugin<void>;
export default plugin;
