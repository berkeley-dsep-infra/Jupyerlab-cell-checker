import { Spinner } from 'spin.js';
export declare function createSpinner(target: HTMLElement): Spinner;
export declare function stopSpinner(spinner: Spinner | null): void;
