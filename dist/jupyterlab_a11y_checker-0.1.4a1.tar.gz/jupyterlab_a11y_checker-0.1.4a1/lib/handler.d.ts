export declare function requestAPI(endpoint: string, init?: RequestInit): Promise<any>;
